package com;

public interface BookObserver {
    void update(String message);
}
