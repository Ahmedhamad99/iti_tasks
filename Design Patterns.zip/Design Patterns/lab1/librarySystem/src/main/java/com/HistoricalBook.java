package com;

public class HistoricalBook extends Book {
    public HistoricalBook(String title) {
        super(title);
    }
}